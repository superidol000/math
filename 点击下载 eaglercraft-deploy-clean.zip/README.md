# Eaglercraft Web

Static deployment of Minecraft 1.8.8 in browser.